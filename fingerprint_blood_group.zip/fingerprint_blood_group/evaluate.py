import numpy as np
import importlib.util
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix

# Step 1: Load model from 'blood_group_cnn_model.h5.py'
model_path = "C:\\Users\\sarik\\OneDrive\\Desktop\\imp\\fingerprint_blood_group\\blood_group_cnn_model.h5.py"
spec = importlib.util.spec_from_file_location("blood_model_module", model_path)
model_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model_module)

model = model_module.model  # Use the model object from the script

# Step 2: Load validation data
datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

val_generator = datagen.flow_from_directory(
    "C:\\Users\\sarik\\OneDrive\\Desktop\\imp\\fingerprint_blood_group\\dataset",
    target_size=(128, 128),
    batch_size=32,
    class_mode='categorical',
    subset='validation',
    shuffle=False
)

# Step 3: Evaluate
predictions = model.predict(val_generator)
y_pred = np.argmax(predictions, axis=1)
y_true = val_generator.classes

# Step 4: Report
class_labels = list(val_generator.class_indices.keys())

print("\nClassification Report:\n")
print(classification_report(y_true, y_pred, target_names=class_labels))

print("\nConfusion Matrix:\n")
print(confusion_matrix(y_true, y_pred))
