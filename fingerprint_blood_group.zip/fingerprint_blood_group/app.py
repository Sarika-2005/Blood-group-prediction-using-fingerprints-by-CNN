from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import os

app = Flask(__name__)
model = load_model("blood_group_cnn_model.h5")
img_size = 128

classes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    if not file:
        return "No file uploaded.", 400

    # Save image
    file_path = os.path.join('static', file.filename)
    file.save(file_path)

    # Preprocess
    image = load_img(file_path, target_size=(img_size, img_size))
    image = img_to_array(image)
    image = image / 255.0
    image = np.expand_dims(image, axis=0)

    prediction = model.predict(image)
    predicted_class = classes[np.argmax(prediction)]
    confidence = round(100 * np.max(prediction), 2)

    return render_template('index.html', prediction=predicted_class, confidence=confidence, img_path=file_path)

if __name__ == '__main__':
    app.run(debug=True)
